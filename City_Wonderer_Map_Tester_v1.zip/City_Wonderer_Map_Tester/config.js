// Edit this file, add images to assets/, then refresh the browser.
// Map keys can be any nonempty strings. null means an empty cell.
export const TILE_SIZE = { width: 512, height: 256 }; // LOGICAL grid, excludes bleed

export const ASSETS = {
  P: 'pavement.png',
  G: 'grass.png',
  R: 'road.png',
  // Explicit metadata is optional for our symmetric ground tiles:
  // X: { file: 'custom.png', label: 'Custom', logicalWidth: 512,
  //      logicalHeight: 256, bleed: 1 },
  // Runtime 258x130 images can also be mixed with 514x258 source images.
  // Their logical size and bleed are detected; both occupy one grid cell.
};

// Columns run down-right; rows run down-left.
export const MAP = [
  ['P', 'P', 'P', 'P', 'P'],
  ['P', 'P', 'P', 'P', 'P'],
  ['R', 'R', 'R', 'R', 'R'],
  ['G', 'G', 'G', 'G', 'G'],
  ['G', 'G', 'G', 'G', 'G'],
];
